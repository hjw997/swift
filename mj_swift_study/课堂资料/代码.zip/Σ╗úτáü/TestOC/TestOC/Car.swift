//
//  Car.swift
//  TestOC
//
//  Created by MJ Lee on 2019/8/4.
//  Copyright © 2019 MJ Lee. All rights reserved.
//

import Cocoa

class Car: NSObject {

}
